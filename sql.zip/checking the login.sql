SELECT * FROM tickets ORDER BY ticket_id DESC LIMIT 5;
